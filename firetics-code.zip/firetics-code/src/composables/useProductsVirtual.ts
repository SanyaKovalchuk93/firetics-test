import { ref, computed, onMounted } from 'vue'

export interface Product {
  title: string
  description: string
  price: number
  discountPercentage: number
  rating: number
  brand: string
  category: string
  thumbnail: string
}

export function useProductsVirtual() {
  const products = ref<Product[]>([])
  const searchQuery = ref('')
  const scrollTop = ref(0)

  const itemHeight = 160
  const containerHeight = 800

  onMounted(async () => {
    const response = await fetch('https://dummyjson.com/products?limit=100')
    const data = await response.json()

    const repeated = new Array(100).fill(null).flatMap(() => data.products)
    products.value = repeated
  })

  function onScroll(container: HTMLElement) {
    scrollTop.value = container.scrollTop
  }

  const filteredProducts = computed(() => {
    const q = searchQuery.value.trim().toLowerCase()
    if (!q) return products.value
    return products.value.filter(p =>
      p.title.toLowerCase().includes(q)
    )
  })

  const visibleCount = Math.ceil(containerHeight / itemHeight) + 2

  const startIndex = computed(() => {
    return Math.floor(scrollTop.value / itemHeight)
  })

  const visibleProducts = computed(() => {
    const start = Math.max(0, startIndex.value)
    const end = Math.min(
      filteredProducts.value.length,
      startIndex.value + visibleCount
    )
    return filteredProducts.value.slice(start, end)
  })

  const totalHeight = computed(() => filteredProducts.value.length * itemHeight)

  return {
    searchQuery,
    products,
    filteredProducts,
    visibleProducts,
    startIndex,
    totalHeight,
    itemHeight,
    containerHeight,
    onScroll,
  }
}