<script lang="ts" setup>
import { ref } from 'vue'
import { useProductsVirtual } from './composables/useProductsVirtual'

const scrollContainer = ref<HTMLElement | null>(null)

const {
  searchQuery,
  visibleProducts,
  startIndex,
  totalHeight,
  itemHeight,
  onScroll,
} = useProductsVirtual()

function handleScroll() {
  if (scrollContainer.value) {
    onScroll(scrollContainer.value)
  }
}
</script>

<template>
  <div class="container">

    <div class="search-bar">
      <input type="text" v-model="searchQuery" placeholder="Поиск..." />
    </div>

    <div
      ref="scrollContainer"
      class="product-list"
      @scroll="handleScroll"
    >
      <div :style="{ height: totalHeight + 'px' }">

        <div
          class="virtual-list-content"
          :style="{ transform: `translateY(${startIndex * itemHeight}px)` }"
        >
          <div
            v-for="(product, i) in visibleProducts"
            :key="product.title + '-' + (startIndex + i)"
            class="product-card"
            :style="{ height: itemHeight + 'px' }"
          >
            <!-- только UI -->
            <div class="product-img">
              <img :src="product.thumbnail" />
            </div>

            <div class="product-info">
              <p class="product-title">{{ product.title }}</p>
              <p class="product-desc">{{ product.description }}</p>

              <div class="highlight-row">
                <p class="discount">Discount {{ product.discountPercentage }}%</p>
                <p class="brand">{{ product.brand }}</p>
              </div>

              <div class="bottom-info">
                <p class="price">${{ product.price }}</p>
                <span class="rating">{{ product.rating }}</span>
                <span class="category">{{ product.category }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<style>
body {
  background-color: #51bbc0;
  overflow: hidden;
}

.container {
  max-width: 460px;
  width: 100%;
  padding-left: 15px;
  padding-right: 15px;
  margin: 0 auto;
}

.search-bar {
  background: white;
  border-radius: 10px;
  padding: 20px;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  height: 40px;
  margin-top: 20px;
}

.search-bar input {
  border: none;
  outline: none;
  font-size: 16px;
  width: 100%;
}

.product-list {
  background: white;
  border-radius: 10px;
  height: 800px;
  overflow-y: scroll;
  overflow-x: hidden;
}

.product-card {
  display: flex;
  padding: 15px;
  height: 160px;
}

.product-list::-webkit-scrollbar {
  width: 10px;
}
.product-list::-webkit-scrollbar-thumb {
  background: #b8d6d7;
  border-radius: 4px;
}

.product-img {
  width: 80px;
  height: 80px;
  border-radius: 12px;
  margin-right: 16px;
  flex-shrink: 0;
}

.product-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.product-info{
  overflow: hidden;
}

.product-title {
  font-weight: 600;
  color: #1c1c1e;
}

.product-desc {
  font-size: 10px;
  color: #666;
}

.highlight-row {
  display: flex;
  align-items: center;
  gap: 20px;
}

.discount {
  font-size: 14px;
  color: #b51f1f;
  font-weight: 600;
  white-space: nowrap;
}

.brand {
  font-size: 14px;
  font-weight: 700;
  color: #368684;
   white-space: nowrap;
}

.bottom-info {
  display: flex;
  align-items: center;
  gap: 20px;
}

.price {
  font-size: 14px;
  font-weight: 700;
  color: #368684;
}

.rating {
  font-size: 14px;
  font-weight: 700;
  color: #368684;
}

.rating::before {
  content: "⭐ ";
}

.category {
  background: #112817;
  color: #56965e;
  font-size: 12px;
  padding: 5px 10px;
  border-radius: 20px;
  font-weight: 600;
}

@media (max-width: 576px){
  .product-img{
    width: 50px;
    height: 50px;
    margin-right: 10px;
  }

  .price,.category,.rating,.product-title,.discount,.brand{
    font-size: 12px;
  }

  .product-desc{
    overflow: hidden;
    height: 60px;
  }
}
</style>
